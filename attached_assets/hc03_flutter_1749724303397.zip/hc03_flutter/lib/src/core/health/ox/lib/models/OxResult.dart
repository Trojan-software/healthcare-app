// ignore_for_file: prefer_typing_uninitialized_variables

class OxResult{
  var ppi;
  
  var r;

  OxResult(this.ppi, this.r);
}