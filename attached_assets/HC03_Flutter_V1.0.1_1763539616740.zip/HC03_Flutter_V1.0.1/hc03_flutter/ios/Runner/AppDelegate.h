#import <Flutter/Flutter.h>
#import <UIKit/UIKit.h>
#import "SDKHealthMoniter.h"

@interface AppDelegate : FlutterAppDelegate
@property (nonatomic, strong) SDKHealthMoniter *sdkHc03;
@end
