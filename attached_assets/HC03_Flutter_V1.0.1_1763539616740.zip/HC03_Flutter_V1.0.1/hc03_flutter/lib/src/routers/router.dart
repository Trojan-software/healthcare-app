import '../pages/tabs/tab.dart';
import 'package:get/get.dart';

var Pages = [
  GetPage(name: "/", page: () => Tabs()),
];


