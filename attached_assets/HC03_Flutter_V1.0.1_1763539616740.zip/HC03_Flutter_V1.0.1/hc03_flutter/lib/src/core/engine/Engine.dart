

abstract class Engine {
  void run(List<int> data);
}